<template>
    <div class="service-list">
        <button class="service-button" @click="handleClick()">Oracle</button>
    </div>
</template>

<style scoped>
    .service-list {
        display: flex;
        gap: 1rem;
        align-items: center;
    }
    .service-button {
        padding: 0.5rem 1rem;
        font-size: 1rem;
        border-radius: 4px;
        color: black;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }
</style>

<script setup lang="ts">
import { serviceApi } from '@/api'
    function handleClick() {
        alert('Service button clicked!');
        serviceApi.oracle()
    }
</script>  